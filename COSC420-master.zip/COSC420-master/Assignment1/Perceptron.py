import numpy as np
import math

class SLP(object):
    def __init__(self, learn_rate, weights, epochs, layers):
        self.learn_rate = learn_rate
        self.weights = weights
        self.epochs = epochs
        self.layers = layers

    def train(self, training, testing):
        for i in range(self.epochs):
            for train, test in zip(training, testing):
                answer = self.activate(train)
                self.weights += self.learn_rate * (test - answer) * train




    def activate(self, input):
        return 1 / (1 + math.exp(-np.dot(input, self.weights)))


train = np.array([[1,0],[1,1]])
test = np.array([1,0])

weights = ([0,0])

#SLP = SLP(0.05, weights, 50)

#SLP.train(train, test)

nn = [None,None,None]




for i in range(0,3):
    nn[i] = SLP(0.05, weights, 50,[2,2,1])
    nn[i].train(train,test)

for i in range(0,3):
    print()
    #print(nn[i].weights)

class Neuron(object):
    def __init__(self, weight):
        self.weight  = weight
        #self.connections = connections




class NN(object):
    def __init__(self, learn_rate, epochs, layers):
        self.learn_rate = learn_rate
        self.epochs = epochs
        self.layers = layers
        self.network = []
        self.training = np.array([[1, 0], [1, 1]])
        self.testing = np.array([1, 0])
        for i in range(0,len(layers)):
            result = []
            for j in range(0,layers[i]):
                result.append(Neuron(0))
            self.network.append(result)
        print(self.network)
        self.train(self.training,self.testing)

    def activate(self, input, weight):
        return 1 / (1 + math.exp(-np.dot(input, weight)))


    def train(self, training, testing):
        for i in range(0, len(self.network[0])):
            #answer = self.activate(training[0][i]);

        for i in range(0, len(self.network)):
            for j in range(0, len(self.network[i])):
                for train, test in zip(training, testing):
                    answer = self.activate(train, self.network[i][j].weight)
                    print(answer)
                    self.weights += self.learn_rate * (test - answer) * train


NN = NN(0.05, 50, [2, 2, 1])



